$(function()
{
	/* FooTable */
	if ($('.footable').length)
		$('.footable').footable();
});
