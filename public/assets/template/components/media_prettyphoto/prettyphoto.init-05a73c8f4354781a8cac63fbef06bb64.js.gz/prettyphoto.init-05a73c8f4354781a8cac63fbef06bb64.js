(function($)
{
	if ($('[data-toggle="prettyPhoto"]').length)
		$('[data-toggle="prettyPhoto"]').prettyPhoto();
})(jQuery);
