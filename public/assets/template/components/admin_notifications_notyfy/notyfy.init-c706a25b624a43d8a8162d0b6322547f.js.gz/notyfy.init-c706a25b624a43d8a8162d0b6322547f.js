//$(document).ready(function () {
//
//    var notification = [];
//
//    notification['alert'] = 'Best check yo self, you\'<strong>re not looking too good</strong>.';
//    notification['primary'] = "<strong>Lorem</strong> Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.";
//    notification['error'] = '<strong>Change a few things up and try submitting again.</strong> This Error message.';
//    notification['success'] = 'You <strong>successfully</strong> read this important alert message.';
//    notification['information'] = 'This alert needs your attention, but it\'s not super <strong>important</strong>.';
//    notification['warning'] = '<strong>Warning!</strong> Best check yo self, you\'re not looking too good.';
//    notification['confirm'] = 'Do you want to continue?';
//
//
//
//    notyfy({
//        text: notification['primary'],
//        type: 'primary',
//        dismissQueue: true,
//        layout: 'topRight'
//
//    });
//});

